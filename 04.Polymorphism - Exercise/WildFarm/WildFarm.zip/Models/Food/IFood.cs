﻿
namespace WildFarm.Models.Food
{
    public interface IFood
    {
        public int Quantity { get; }
    }
}
