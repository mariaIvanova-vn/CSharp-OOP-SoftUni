﻿using System;

namespace AuthorProblem
{
    [AuthorAttribute("Maria")]
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
